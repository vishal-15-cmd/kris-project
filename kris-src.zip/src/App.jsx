import { useState } from 'react'
import { Routes, Route } from 'react-router-dom';
import Login from './pages/admins/auth/login';
import Home from './pages/Home';
import AdminDashboard from './pages/admins/auth/dashboard/AdminDashboard';
import LeaveManagement from './pages/admins/auth/dashboard/LeaveManagement';
import LeaveRecall from './pages/admins/auth/dashboard/LeaveRecall';
import LeaveSettings from './pages/admins/auth/dashboard/LeaveSettings';
import './App.css'
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import Headerbar from './components/Headerbar'
import PersonalDetails from './components/updateProfiles/PersonalDetails';
import ContactDetails from './components/updateProfiles/ContactDetails';
import NextOfKinDetails from './components/updateProfiles/NextOfKinDetails';
import FinancialDetails from './components/updateProfiles/FinancialDetails';
import EducationalQualifications from './components/updateProfiles/EducationalQualifications';
import GuarantorDetails from './components/updateProfiles/GuarantorDetails';
import FamilyDetails from './components/updateProfiles/FamilyDetails';
import JobDetails from './components/updateProfiles/JobDetails';
import EmployeeRegister from './pages/employees/auth/EmployeeRegister'
import EmployeeLogin from './pages/employees/auth/EmployeeLogin';
import EmployeeLayout from './layouts/EmployeeLayout';
import AdminLayout from './layouts/AdminLayout';
import ApplyForLeave from './pages/employees/auth/dashboard/ApplyForLeave';
import AnnualLeaveApplication from './pages/employees/auth/dashboard/AnnualLeaveApplication';
import SickLeaveApplication from './pages/employees/auth/dashboard/SickLeaveApplication';
import EmployeeDasboard from './pages/employees/auth/dashboard/EmployeeDashboard';



function App() {
  return (
    <div>
      {/*<Navbar />
      <Headerbar />*/}
      <Routes>
        <Route path="/" element={<Home />}></Route>


        <Route path="/employee" element={<EmployeeLayout />}>
          <Route path="" element={<EmployeeLogin />}></Route>
          <Route path="register" element={<EmployeeRegister />}></Route>
          <Route path="dashboard" element={<EmployeeDasboard />}></Route>


          <Route path="apply-for-leave" element={<ApplyForLeave />}></Route>
          <Route path="annual-leave-applications" element={<AnnualLeaveApplication />}></Route>
          <Route path="sick-leave-applications" element={<SickLeaveApplication />}></Route>
        </Route>


        <Route path="/admin" element={<AdminLayout />}>
          <Route path="" element={<Login />}></Route>
          <Route path="dashboard" element={<AdminDashboard />}></Route>
          <Route path="leave-management" element={<LeaveManagement />}></Route>
          <Route path="leave-recall" element={<LeaveRecall />}></Route>
          <Route path="leave-settings" element={<LeaveSettings />}></Route>
        </Route>


        <Route path="/dashboard" element={<Dashboard />}>
          <Route path="personal-details" element={<PersonalDetails />}></Route>
          <Route path="contact-details" element={<ContactDetails />}></Route>
          <Route path="next-of-kin-details" element={<NextOfKinDetails />}></Route>
          <Route path="educational-qualifications" element={<EducationalQualifications />}></Route>
          <Route path="guarantor-details" element={<GuarantorDetails />}></Route>
          <Route path="family-details" element={<FamilyDetails />}></Route>
          <Route path="job-details" element={<JobDetails />}></Route>
          <Route path="financial-details" element={<FinancialDetails />}></Route>

        </Route>

      </Routes>
    </div>
  )
}

export default App
