import {Outlet} from 'react-router-dom';


function EmployeeLayout () {
    return (
        <div>
            <Outlet></Outlet>
        </div>
    )
}
export default EmployeeLayout;