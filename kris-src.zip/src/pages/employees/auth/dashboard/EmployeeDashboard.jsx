function EmployeeDasboard () {
    return (
        <div>
            hello
        </div>
    )
}
export default EmployeeDasboard;