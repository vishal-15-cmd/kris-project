import Headerbar from "../../../../components/Headerbar";
import Navbar from "../../../../components/Navbar";
import BookOpen from '../../../../assets/BookOpen.png'
import {  } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';



 
 
  
 

function LeaveApplication() {
    const leaveOptions = [
        {
            id: 1,
            type: "Annual Leave",
            available: 60,
            color: "bg-blue-600",
        },
        {
            id: 2,
            type: "Sick Leave",
            available: 20,
            color: "bg-blue-600",
        },
        {
            id: 3,
            type: "Maternity Leave",
            available: 60,
            color: "bg-blue-600",
        },
        {
            id: 4,
            type: "Compassionate Leave",
            available: 30,
            color: "bg-blue-600",
        },
    ];

    const leaveDetails = [
        {
            "name": "John Doe",
            "duration": "5 days",
            "startDate": "2024-01-10",
            "endDate": "2024-01-15",
            "type": "Sick Leave",
            "reason": "Flu and fever"
        },
        {
            "name": "Jane Smith",
            "duration": "3 days",
            "startDate": "2024-02-05",
            "endDate": "2024-02-07",
            "type": "Casual Leave",
            "reason": "Family event"
        },
        {
            "name": "Alex Johnson",
            "duration": "10 days",
            "startDate": "2024-03-15",
            "endDate": "2024-03-25",
            "type": "Annual Leave",
            "reason": "Vacation trip"
        },
        {
            "name": "Emily Davis",
            "duration": "2 days",
            "startDate": "2024-04-12",
            "endDate": "2024-04-13",
            "type": "Sick Leave",
            "reason": "Examination"
        },
        {
            "name": "Michael Brown",
            "duration": "7 days",
            "startDate": "2024-05-01",
            "endDate": "2024-05-07",
            "type": "Maternity/Paternity Leave",
            "reason": "child care"
        }
    ]


    return (
        <div>
            <Navbar />
            <Headerbar />
            <div className="bg-white w-5/6 p-10 place-center m-auto">
                {/*for leave appliction */}
                <div className="flex">
                    <img src={BookOpen} alt="icon"></img>
                    <h4 className="p-2 ps-3 font-semibold">Leave Application</h4>

                </div>
                <div className="flex flex-wrap p-2">
                    {leaveOptions.map((leave) => (
                        <div className="flex flex-wrap bg-indigo-700 rounded-md p-6 m-2 " key={leave.id}>
                            <span className="rounded-full bg-white p-4 m-2">{leave.available}</span>
                            <div className="m-2 text-white">
                                <h4>Annual leave</h4>
                                <button className="bg-yellow-500 rounded-md  px-8 m-1">Apply</button>
                            </div>
                        </div>
                    )
                    )}
                </div>
                {/*for leave History*/}
                <div className="m-2 ">
                    <h4 className="p-2 ps-3 font-semibold">Leave History</h4>
                    <TableContainer component={Paper} className="align-center" >
                        <Table sx={{ minWidth: 550 }} aria-label="customized table">
                            <TableHead>
                                <TableRow className="bg-blue-100">
                                    <TableCell>Name(s)</TableCell>
                                    <TableCell align="right">Duration(s)</TableCell>
                                    <TableCell align="right">Start date</TableCell>
                                    <TableCell align="right">End Date</TableCell>
                                    <TableCell align="right">Type</TableCell>
                                    <TableCell align="right">Reasons</TableCell>
                                    <TableCell align="right">Actions</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {leaveDetails.map((leaveDetail) => (
                                    <TableRow key={leaveDetail.name}>
                                        <TableCell component="th" scope="row">{leaveDetail.name}</TableCell>
                                        <TableCell  align="right">{leaveDetail.duration}</TableCell>
                                        <TableCell align="right">{leaveDetail.startDate}</TableCell>
                                        <TableCell align="right">{leaveDetail.endDate}</TableCell>
                                        <TableCell align="right">{leaveDetail.type}</TableCell>
                                        <TableCell align="right">{leaveDetail.reason}</TableCell>
                                        <TableCell align="right"><button className="bg-indigo-800 px-4 text-white py-1">Action</button></TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
            </div>
        </div>
    )
}
export default LeaveApplication;