import Navbar from '../../../../components/Navbar';
import Headerbar from '../../../../components/Headerbar';
import BookOpen from '../../../../assets/BookOpen.png';
import { useForm } from 'react-hook-form';

function AnnualLeaveApplication() {
    const { register, handleSubmit, formState: { errors }, watch } = useForm();

    return (
        <div>
            <Navbar />
            <Headerbar />
            <div className='bg-white w-3/6 m-auto place-items-center'>
                <div className="flex flex-wrap  justify-center m-auto p-2">
                    <div>
                        <img className=' m-1' src={BookOpen} alt="icon"></img>
                    </div>
                    <div>
                        <h2 className='font-bold font-2xl pt-1 m-1'>Leave Application</h2>
                    </div>
                </div >
                <small className=" font-medium pb-4 p-1 m-1">Fill the required fields below to aplly for annual leave</small>

                {/*application form */}

                <div className=" m-auto sm:mx-auto sm:w-full">
                    <form className="px-14 py-2 m-auto"  >
                        <div className="m-4">
                            <label htmlFor="annualLeave" className="block text-sm/6 font-medium text-start text-gray-900">Leave type</label>
                            <div>
                                <input type="text"  id="annualLeave" value='Annual Leave' readOnly {...register('annualLeave')} className="block w-full me-5 border-0 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                            </div>
                        </div>
                        <div className='flex flex-wrap m-4 justify-between '>
                            <div>
                                <label htmlFor="date">Start Date</label>
                                <div className='w-max '>
                                    <input type="date" name="startDate" id="startDate" {...register('startDate')} className="block w-full me-5 border-0 rounded-md bg-blue-50 px-16 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                </div>
                            </div>
                            <div>
                                <label htmlFor="date">End Date</label>
                                <div className='w-max '>
                                    <input type="date" name="endDate" id="endDate" {...register('endDate')} className="block w-full me-5 border-0 rounded-md bg-blue-50 px-16 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                </div>
                            </div>
                        </div>

                        <div className='flex flex-wrap m-4  justify-between '>
                            <div>
                                <label htmlFor="date">Duration</label>
                                <div className='w-max '>
                                    <input type="number" name="duration" id="duration" {...register('duration')} className="block w-full me-5 border-0 rounded-md bg-blue-50 px-12 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                </div>
                            </div>
                            <div>
                                <label htmlFor="date">Resumption Date</label>
                                <div className='w-max '>
                                    <input type="date" name="resumptionDate" id="resumptionDate" {...register('resumptionDate')} className="block w-full me-5 border-0 rounded-md bg-blue-50 px-16 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                </div>
                            </div>
                        </div>


                        <div className="m-4" >
                            <label htmlFor="reasonForLeave" className="block text-sm/6 text-left font-medium text-gray-900">Reason for leave</label>
                            <div className="">
                                <textarea type="text" id="reasonForLeave" name="reasonForLeave" {...register('reasonForLeave')} className="block w-full border-0 me-4 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"></textarea>
                            </div>
                        </div>

                        <div className='m-4'>
                            <label htmlFor="" className="block text-sm/6 text-left font-medium text-gray-900" >Choose Relief Officer</label>
                            <div>
                                <select name="officerName" id="officerName" placeholder="select your relief officer" className="block w-full border-0 mt-1 me-4 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6">
                                    <option>select your relief officer</option>
                                    <option>John</option>
                                    <option>Dohn</option>
                                    <option>Brandohn</option>
                                </select>
                            </div>
                        </div>

                        <div className='flex justify-center flex-wrap m-2'>
                            <div className="px-6 py-2 m-1 text-start">
                                <button type="submit" className="relative rounded-md bg-green-600 px-16 py-2 text-sm/6 font-semibold text-white shadow-sm  focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Submit</button>
                            </div>
                            <div className="px-6 py-2 m-1 text-start">
                            <button type="reset" className="relative rounded-md border border-red-600 px-16 py-2 text-sm/6 font-semibold text-red-600 shadow-sm  focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Reset</button>
                        </div>

                        </div>

                    </form>
                </div>
            </div>
        </div>
    )
}
export default AnnualLeaveApplication;