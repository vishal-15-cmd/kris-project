import { useForm } from "react-hook-form";
import Logo from '../../../assets/Logo.png'
import EmployeeloginBgImage from '../../../assets/EmployeeloginBgImage.png';
import { useEffect, useState } from "react";
import {Link,useNavigate} from 'react-router-dom';
import axios from 'axios'

function EmployeeLogin() {
    const style = {
        backgroundImage: `linear-gradient(rgba(4, 4, 251, 0.5),rgba(4, 4, 251, 0.5)),url(${EmployeeloginBgImage})`,
        backgroundBlendmode: 'overlay',
        backgroundSize: 'cover',
        minheight: '100vh'
    }
    const { register, handleSubmit, formState: { errors }, watch } = useForm();
    const [employees, setEmployees] = useState([]);
    const [errmsg, setErrmsg] = useState(null);
    const navigate = useNavigate();

    useEffect(() =>{
        getEmployees();
    },[]);

    const getEmployees = async() =>{
        try {
            const response = await axios.get('http://localhost:4000/employees?role=employee');
            console.log(response.data);
            setEmployees(response.data)
        }catch(error) {
            console.log(error);
        }
    }

    const handleLogin = async(formData) =>{
        const findEmployee = employees.find(employee =>employee.email===formData.email && employee.password ===formData.password)
            if(findEmployee ){
                navigate('/employee/dashboard');
                console.log(email,password)
            }else {
                setErrmsg('Incorrect email or password');
            }
        
    } 

    return (
        <div className="flex h-screen ">
            <div className="flex w-2/5 max-h-full m-auto bg-white flex-col justify-center h-screen px-6 lg:px-8"  >
                <div className=" items-start">
                    <img src={Logo} alt="logo" />
                </div>
                <div className="sm:mx-auto sm:w-full sm:max-w-sm">

                    <h2 className="mt-10 text-center text-2xl/9 font-bold tracking-tight text-blue-800">Login</h2>
                    <h4 className="m-auto mt-4 text-center text-gray-500">Login to your account</h4>
                </div>
                {errmsg && <p className="text-red-500 text-center pt-6">{errmsg}</p>}
                <div className="mt-5 sm:mx-auto sm:w-full sm:max-w-sm">
                    <form className="space-y-6 m-auto pb-10" onSubmit= {handleSubmit(handleLogin)}>
                        <div>
                            <label htmlFor="email" className="block text-sm/6 font-medium text-gray-900">Email address</label>
                            <div className="mt-2">
                                <input type="text" name="email" id="email" {...register('email', { required: { value: true, message: 'email is required' }, pattern: { value: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/, message: 'in correct email' } })} className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                <p className="text-sm text-red-400">{errors.email?.message}</p>

                            </div>
                        </div>

                        <div>
                            <div className="flex items-center justify-between">
                                <label htmlFor="password" className="block text-sm/6 font-medium text-gray-900">Password :</label>

                            </div>
                            <div className="mt-2">
                                <input type="password" name="password" id="password" {...register('password', { required: { value: true, message: 'password is required' } })} className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                <p className="text-sm text-red-400">{errors.password?.message}</p>

                            </div>
                        </div>
                        <div>
                            <div className='flex flex-wrap justify-between'>
                                <div>
                                    <input type="checkbox" name="rememberMe" id="rememberMe" /><label>Remember me</label>
                                </div>
                                <div className="text-sm">
                                    <a href="#" className="font-semibold hover:text-indigo-500">Reset password?</a>
                                </div>
                            </div>
                        </div>

                        <div>
                            <button type="submit" className="flex w-full justify-center rounded-md bg-blue-500 px-3 py-1.5 text-sm/6 font-semibold text-black shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Sign In</button>
                        </div>
                        <div className="text-center text-blue">
                            <small >Don't have an account yet?<Link to="/employee/register" className="text-blue-800 text-md">Join KRIS Today</Link></small>
                        </div>
                    </form>

                </div>
            </div>
            <div className="w-3/5  align-middle text-wrap" style={style}>
                <h1 className="text-white p-4 align-text-bottom pt-6 text-wrap pb-20 text-2xl font-extrabold">Manage all<span className="text-yellow-400"> HR Operations</span> from the comfort of your home</h1>
            </div>
        </div>

    )
}
export default EmployeeLogin;