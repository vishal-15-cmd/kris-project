import Logo from '../assets/Logo.png';
import {useNavigate} from 'react-router-dom'

function Home() {
    const navigate = useNavigate();


    const navigateEmpLogin = () => {
        navigate('/employee')
    }

    const navigateAdminlogin = () => {
        navigate('/admin');
    }
    
    return (
        <div className="bg-blue-300 h-screen flex items-center justify-center">
            <div className="bg-white border-2 border-white rounded-md shadow-md p-6 max-w-md w-full">
                <div className="flex justify-center mb-4">
                    <img src={Logo} alt="Company Logo" className="w-26 h-20" />
                </div>
                <h1 className="text-2xl font-bold text-center text-blue-800">Welcome</h1>
                <h4 className="text-center text-gray-600 mt-2 mb-6">Choose an option to proceed</h4>
                <div className="flex flex-col space-y-4">
                    <button onClick={navigateAdminlogin} className="bg-blue-700 text-white font-medium py-2 px-4 rounded-md hover:bg-blue-800 transition">Admin Login</button>
                    <button onClick={navigateEmpLogin} className="bg-green-700 text-white font-medium py-2 px-4 rounded-md hover:bg-green-800 transition" >Employee Login</button>
                </div>
            </div>
        </div>
    );
}
export default Home;