function LeaveSettings() {
    return (
        <div>
            <div className='bg-blue-900 rounded-xl mx-8 w-4xl h-50 mt-16 content-center'>
                <h1 className='text-2xl text-white font-bold px-6'>Manage All <span className='text-yellow-500'>Leave Applications</span></h1>
                <p className='text-white text-sm px-6'>A relaxed employee is a performing employee.</p>
            </div>
        </div>
    )
}
export default LeaveSettings;