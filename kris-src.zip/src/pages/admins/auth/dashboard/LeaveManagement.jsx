import SideNavbar from "../../../../components/SideNavbar";
import AdminNavbar from "../../../../components/AdminNavbar";
import {Link,useLocation} from 'react-router-dom';
import { Outlet } from "react-router-dom";



function LeaveManagement() {
const location = useLocation();

    return (

        <div className='flex flex-wrap justify-center'>
            <div className="w-1/5">
                <SideNavbar />
            </div>
            <div className="w-4/5">
                <div >
                    <AdminNavbar />
                    <div className="p-2">
                        <p><i className="fa-solid fa-book-open pr-2 my-6"></i>Leave Management</p>
                        <div className='flex justify-between'>
                        <button className={`bg-blue-900 rounded-lg text-white p-2 px-12 shadow-lg hover:bg-indigo-600 ${ location.pathname === "/admin/leave-settings" ? "bg-yellow-600" : ""}`}><Link to="/admin/leave-settings">Leave Setting</Link></button>
                        <button className={`bg-blue-900 rounded-lg text-white p-2 px-12 shadow-lg hover:bg-indigo-600 ${ location.pathname === "/admin/leave-recall" ? "bg-yellow-600" : ""}`}><Link to="/admin/leave-recall">Leave Recall</Link></button>
                        <button className={`bg-blue-900 rounded-lg text-white p-2 px-12 shadow-lg hover:bg-indigo-600 ${ location.pathname === "/admin/leave-recall" ? "bg-yellow-600" : ""}`}><Link to="/admin/leave-recall">Leave History</Link></button>
                        <button className={`bg-blue-900 rounded-lg text-white p-2 px-12 shadow-lg hover:bg-indigo-600 ${ location.pathname === "/admin/leave-recall" ? "bg-yellow-600" : ""}`}><Link to="/admin/leave-recall">Relief Officers</Link></button>
                        </div>
                    </div>
                    <div>
                        <Outlet />
                    </div>
                </div>
            </div>

        </div>

    )
}

export default LeaveManagement;