import SideNavbar from "../../../../components/SideNavbar";
import AdminNavbar from "../../../../components/AdminNavbar";

import MessageIcon from '../../../../assets/MessageIcon.png'
import Jobs from '../../../../assets/Jobs.png'
import Candidates from '../../../../assets/Candidates.png'
import Resumes from '../../../../assets/Resumes.png'
import User from '../../../../assets/User.png'
import BookOpen from '../../../../assets/BookOpen.png'
import Payroll from '../../../../assets/Payroll.png'

import Ellipsis from '../../../../assets/Ellipsis-v.png'
import SalesExecutive from '../../../../assets/SalesExecutive.png'
import UserExperience from '../../../../assets/UserExperience.png'
import ProductManager from '../../../../assets/ProductManager.png'
import JohnDoe from '../../../../assets/JohnDoe.png'

function AdminDashboard() {
    return (
        <div className='flex  flex-wrap justify-center'>
            <div className="w-1/5 h-screen  ">
                <SideNavbar />
            </div>
            <div className="w-4/5 h-screen">
                <div>
                    <AdminNavbar />
                </div>

                <div >
                    <p className='font-bold pl-2'>Dashboard</p>
                    <div className='flex  justify-between gap-2 p-2 text-white'>
                        <div className='w-1/7 py-4 px-6 border-none rounded  bg-yellow-500 flex justify-between'>
                            <img src={MessageIcon} />
                            <div>
                                <p className='font-bold'>138</p>
                                <span className='font-semibold'>Messages</span>
                            </div>
                        </div>
                        <div className='w-1/7 py-4 px-6 border-none rounded  bg-blue-900 flex justify-between'>
                            <img src={Jobs} />
                            <div>
                                <p className='font-bold'>138</p>
                                <span className='font-semibold'>Jobs</span>
                            </div>
                        </div>
                        <div className='w-1/7 py-4 px-6 border-none rounded  bg-green-700 flex justify-between'>
                            <img src={Candidates} />
                            <div>
                                <p className='font-bold'>138</p>
                                <span className='font-semibold'>Candidates</span>
                            </div>
                        </div>
                        <div className='w-1/7 py-4 px-6 border-none rounded  bg-black flex justify-between'>
                            <img src={Resumes} />
                            <div >
                                <p className='font-bold'>138</p>
                                <span className='font-semibold'>Resumes</span>
                            </div>
                        </div>
                        <div className='w-1/7 py-4 px-6 border-none rounded  bg-yellow-500 flex justify-between'>
                            <img src={User} />
                            <div>
                                <p className='font-bold'>138</p>
                                <span className='font-semibold'>Employees</span>
                            </div>
                        </div>
                        <div className='w-1/7 py-4 px-6 border-none rounded  bg-blue-950 flex justify-between'>
                            <img  className="bg-white" src={BookOpen} />
                            <div>
                                <p className='font-bold'>138</p>
                                <span className='font-semibold'>Leaves</span>
                            </div>
                        </div>
                        <div className='w-1/7 py-4 px-6 border-none rounded  bg-green-700  flex justify-between'>
                            <img src={Payroll} />
                            <div>
                                <p className='font-bold'>138</p>
                                <span className='font-semibold'>Payrolls</span>
                            </div>
                        </div>

                    </div>
                </div>
                <div className='grid grid-cols-2 p-2 gap-3'>
                    <div className=' container bg-white p-2 border-none rounded'>
                        <div className='flex justify-between'>
                            <p className='font-bold'>Applied Jobs</p>
                            <img src={Ellipsis} className='h-5' />
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex '>
                                <img src={SalesExecutive} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>Sales Executive</p>
                                    <span className='text-gray-500 text-sm'>Access Bank</span>
                                </div>
                            </div>
                            <p className='text-gray-500'>20 mins ago</p>
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex '>
                                <img src={UserExperience} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>User Experience Designer</p>
                                    <span className='text-gray-500 text-sm'>Paystack</span>
                                </div>
                            </div>
                            <p className='text-gray-500'>10 mins ago</p>
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex '>
                                <img src={ProductManager} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>Product Manager</p>
                                    <span className='text-gray-500 text-sm'>T-Pay</span>
                                </div>
                            </div>
                            <p className='text-gray-500'>5 mins ago</p>
                        </div>
                    </div>
                    <div className=' container bg-white p-2 border-none rounded'>
                        <div className='flex justify-between'>
                            <p className='font-bold'>Employees</p>
                            <img src={Ellipsis} className='h-5' />
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className=' container bg-white p-2 border-none rounded'>
                        <div className='flex justify-between'>
                            <p className='font-bold'>Employees</p>
                            <img src={Ellipsis} className='h-5' />
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className=' container bg-white p-2 border-none rounded'>
                        <div className='flex justify-between'>
                            <p className='font-bold'>Employees</p>
                            <img src={Ellipsis} className='h-5' />
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                        <div className='flex justify-between bg-sky-100 p-1 border-none rounded mt-2'>
                            <div className='flex gap-2 '>
                                <img src={JohnDoe} className='h-12' />
                                <div>
                                    <p className='font-bold text-sm'>John Doe</p>
                                    <span className='text-gray-500 text-sm'>Role : Product Manager </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default AdminDashboard

