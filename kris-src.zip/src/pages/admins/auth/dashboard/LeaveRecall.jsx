
import BookOpen from '../../../../assets/BookOpen.png'
import { } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import AdminNavbar from "../../../../components/AdminNavbar";
import SideNavbar from "../../../../components/SideNavbar";

function LeaveRecall() {
    const leaveOptions = ['Leave Settings', 'Leave Recall', 'Leave History', 'Relief Officer'];

    const leaveDetails = [
        {
            "name": "John Doe",
            "duration": "5 days",
            "startDate": "2024-01-10",
            "endDate": "2024-01-15",
            "type": "Sick Leave",
            "reason": "Flu and fever"
        },
        {
            "name": "Jane Smith",
            "duration": "3 days",
            "startDate": "2024-02-05",
            "endDate": "2024-02-07",
            "type": "Casual Leave",
            "reason": "Family event"
        },
        {
            "name": "Alex Johnson",
            "duration": "10 days",
            "startDate": "2024-03-15",
            "endDate": "2024-03-25",
            "type": "Annual Leave",
            "reason": "Vacation trip"
        },
        {
            "name": "Emily Davis",
            "duration": "2 days",
            "startDate": "2024-04-12",
            "endDate": "2024-04-13",
            "type": "Sick Leave",
            "reason": "Examination"
        },
        {
            "name": "Michael Brown",
            "duration": "7 days",
            "startDate": "2024-05-01",
            "endDate": "2024-05-07",
            "type": "Maternity/Paternity Leave",
            "reason": "child care"
        }
    ]


    return (
        <div className='flex  flex-wrap justify-center'>
            <div className="w-1/5 h-screen  ">
                <SideNavbar />
            </div>
            <div className="w-4/5 h-screen">
                <div>
                    <AdminNavbar />
                </div>


                <div className="  p-10 place-center m-auto">
                    {/*for leave appliction */}
                    <div className="flex">
                        <img src={BookOpen} alt="icon"></img>
                        <h4 className="p-2 ps-3 font-semibold">Leave Manangement</h4>

                    </div>
                    <div className="flex flex-wrap justify-between p-2">
                        {leaveOptions.map((leave) => (
                            <div key={leave.id}>

                                <button className="flex flex-wrap text-white bg-indigo-700 rounded-md px-6 py-2 m-2 ">{leave}</button>

                            </div>
                        )
                        )}
                    </div>
                    {/*for leave History*/}
                    <div className="m-2 ">
                        <h4 className="p-2 ps-3 font-semibold">On Going Leave Applications</h4>
                        <TableContainer component={Paper} className="align-center" >
                            <Table sx={{ minWidth: 550 }} aria-label="customized table">
                                <TableHead>
                                    <TableRow className="bg-blue-100">
                                        <TableCell>Name(s)</TableCell>
                                        <TableCell align="right">Duration(s)</TableCell>
                                        <TableCell align="right">Start date</TableCell>
                                        <TableCell align="right">End Date</TableCell>
                                        <TableCell align="right">Type</TableCell>
                                        <TableCell align="right">Reasons</TableCell>
                                        <TableCell align="right">Actions</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {leaveDetails.map((leaveDetail) => (
                                        <TableRow key={leaveDetail.name}>
                                            <TableCell component="th" scope="row">{leaveDetail.name}</TableCell>
                                            <TableCell align="right">{leaveDetail.duration}</TableCell>
                                            <TableCell align="right">{leaveDetail.startDate}</TableCell>
                                            <TableCell align="right">{leaveDetail.endDate}</TableCell>
                                            <TableCell align="right">{leaveDetail.type}</TableCell>
                                            <TableCell align="right">{leaveDetail.reason}</TableCell>
                                            <TableCell align="right"><button className="bg-red-500 px-4 rounded-sm text-white py-1">Recall</button></TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default LeaveRecall;