import { useForm } from 'react-hook-form'
import { ToastContainer, toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { useEffect, useState } from 'react';
import Logo1 from '../../../assets/Logo1.png'
import BgImage1 from '../../../assets/BgImage1.png';


function Login() {
    const style = {
        backgroundImage: `linear-gradient(rgba(47, 7, 246, 0.77),rgba(28, 13, 245, 0.74)),url(${BgImage1})`,
        backgroundBlendmode: 'overlay'

    }

    const { register, handleSubmit, formState: { errors }, watch } = useForm();
    const [admins, setAdmins] = useState([]);
    const [errmsg, setErrmsg] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        getAdmins();
    }, []);

    const getAdmins = async () => {
        try {
            const response = await axios.get('http://localhost:4000/employees?role=admin');
            console.log(response.data);
            setAdmins(response.data);
        } catch (error) {
            console.log(error);
        }
    }

    const loginUser = (formData) => {
        const findAdmin = admins.find((admin) => {
            if (admin.email === formData.email && admin.password === formData.password) {
                return navigate('/admin/dashboard');

            } else {
                setErrmsg("Incorrect email or password");
            }
        });
        
    }
    return (
        <div className='h-screen' style={style}>

            <div className="flex w-full max-h-full m-auto flex-col justify-center px-6 lg:px-8"  >
                <div className=" items-start">
                    <img src={Logo1} alt="logo" />
                </div>
                <div className="sm:mx-auto sm:w-full sm:max-w-sm">

                    <h2 className="mt-10 text-center text-2xl/9 font-bold tracking-tight text-white">Login</h2>
                    <h4 className="m-auto mt-4 text-center text-white">Login to your account</h4>
                </div>
                {errmsg && <p className="text-red-600 mt-4">{errmsg}</p>}

                <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
                    <form className="space-y-6 m-auto pb-10" onSubmit={handleSubmit(loginUser)}>
                        <div>
                            <label htmlFor="email" className="block text-sm/6 font-medium text-white">Email address</label>
                            <div className="mt-2">
                                <input type="text" name="email" id="email" {...register('email', { required: { value: true, message: 'email is required' }, pattern: { value: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/, message: 'in correct email' } })} className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                <p className="text-sm text-red-400">{errors.email?.message}</p>

                            </div>
                        </div>

                        <div>
                            <div className="flex items-center justify-between">
                                <label htmlFor="password" className="block text-sm/6 font-medium text-white">Password :</label>

                            </div>
                            <div className="mt-2">
                                <input type="password" name="password" id="password" {...register('password', { required: { value: true, message: 'password is required' }})} className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                <p className="text-sm text-red-400">{errors.password?.message}</p>

                            </div>
                        </div>
                        <div>
                            <div className='flex flex-wrap justify-between'>
                                <div>
                                    <input type="checkbox" name="rememberMe" id="rememberMe" /><label className="text-white">Remember me</label>
                                </div>
                                <div className="text-sm">
                                    <a href="#" className="font-semibold text-white hover:text-indigo-500">Reset password?</a>
                                </div>
                            </div>
                        </div>


                        <div>
                            <button type="submit" className="flex w-full justify-center rounded-md bg-yellow-500 px-3 py-1.5 text-sm/6 font-semibold text-black shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Sign In</button>
                        </div>
                    </form>


                </div>
                <div>
                    <ToastContainer />
                </div>
            </div>
        </div>
    )
}
export default Login;