function Headerbar() {
    return (
        <div className="m-4">
            <div className="w-6/7 p-4 m-auto bg-white  hover:border-2 border-blue-400 align-center">
                <h2 className="hover:underline decoration-blue-300">Dasboard--Update Profile</h2>
            </div>
        </div>
    )
}
export default Headerbar;