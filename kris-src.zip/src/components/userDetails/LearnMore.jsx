function LearnMore() {
    return(
        <div>
            <h1>Learn More</h1>
        </div>
    )
}
export default LearnMore;