function OurFeatures() {
    return(
        <div>
            <h1>our features</h1>
        </div>
    )
}
export default OurFeatures;