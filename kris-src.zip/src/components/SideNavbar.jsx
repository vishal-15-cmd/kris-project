import Logo1 from '../assets/Logo1.png';
import ProfileIcon from '../assets/ProfileIcon.png';
import { Link } from 'react-router-dom';

function SideNavbar() {
    return (
        <div className='bg-indigo-900  h-screen '>
            <div className=" text-white shadow-lg border border-gray-600">
                <div>
                    <img src={Logo1} alt="Icon" className='snap-center mt-4 m-auto w-22 h-16' />
                </div>
                <div className='flex flex-wrap justify-self-center m-2 spaxe-x-4'>
                    <img src={ProfileIcon} alt="profile Icon" className='m-2 place-center w-16 h-16 ' />
                    <div className="p-1 pt-4">
                        <h2 className="font-bold">KRIS Admin</h2>
                        <small>Admin</small>
                    </div>
                </div>
                <div className='m-4 '>
                    <h4>Features</h4>
                    <ul>
                        <li className=" px-8 shadow-md text-xs py-3 hover:bg-yellow-600"><Link to="/admin/dashboard">Dashboard</Link></li>
                        <li className=" px-8 shadow-md text-xs py-3 hover:bg-yellow-600"><Link to="#">Messages</Link></li>
                    </ul>
                    <h4>Recruitments</h4>
                    <ul>
                        <li className=" px-8 shadow-md text-xs py-3 hover:bg-yellow-600"><Link to="#">Jobs</Link></li>
                        <li className=" px-8 shadow-md text-xs py-3 hover:bg-yellow-600"><Link to="#">Candidates</Link></li>
                        <li className=" px-8 shadow-md text-xs py-3 hover:bg-yellow-600"><Link to="#">Resumes</Link></li>
                    </ul>
                    <h4>Oraganization</h4>
                    <ul>
                        <li className=" ps-2 shadow-md text-xs py-3 "><Link className="hover:bg-yellow-600" to="#">Employee Management</Link>
                            <ul>
                                <li className=" ps-3 shadow-md text-xs py-3 hover:bg-yellow-600"><Link  to="/admin/leave-management">Leave Management</Link></li>
                            </ul>
                        </li>
                        <li className=" ps-2 shadow-md text-xs py-3 hover:bg-yellow-600"><Link to="#">Performance Management</Link></li>
                    </ul>
                    <h4>KRIS Pay</h4>
                    <ul>
                        <li className="  shadow-md text-xs py-3 hover:bg-yellow-600"><Link to="#">Payroll Management</Link></li>
                    </ul>
                    <button className="bg-red-500 px-10 py-1 rounded-md  mt-4 m-auto">Logout</button>

                </div>
            </div>
        </div>

    )
}
export default SideNavbar;