import { Link, Outlet } from 'react-router-dom';
import {useLocation} from 'react-router-dom';
import Navbar from '../components/Navbar';
import Headerbar from './Headerbar';


function Dashboard() {
    const location = useLocation();
    

    return (
        <div>
            <Navbar />
            <Headerbar />
            <div className="flex flex-wrap justify-center text-center ">
            <div className=" rounded-md w-1/5 m-2 bg-white hover:border-4 border-blue-400">
               
                <ul className="p-4  mx-2">
                    <li className={`rounded-md bg-blue-50 my-4 p-3  text-xs text-black font-semibold  hover:border-2 border-blue-400 ${location.pathname === '/dashboard/personal-details' ? 'bg-yellow-200' : ' '}  `} ><Link to="/dashboard/personal-details" className=" hover:underline decoration-2 decoration-blue-400">Personal Details</Link></li>
                    <li className={`rounded-md bg-blue-50 my-4 p-3  text-xs text-black font-semibold  hover:border-2 border-blue-400 ${location.pathname === '/dashboard/contact-details' ? 'bg-yellow-200' : ' '}  `}><Link to="/dashboard/contact-details" className=" hover:underline decoration-solid decoration-2 decoration-blue-400">Contact Details</Link></li>
                    <li className={`rounded-md bg-blue-50 my-4 p-3  text-xs text-black font-semibold  hover:border-2 border-blue-400 ${location.pathname === '/dashboard/next-of-kin-details' ? 'bg-yellow-200' : ' '}  `}><Link to="/dashboard/next-of-kin-details" className=" hover:underline decoration-solid decoration-2 decoration-blue-400">Next of kin Details</Link></li>
                    <li className={`rounded-md bg-blue-50 my-4 p-3  text-xs text-black font-semibold  hover:border-2 border-blue-400 ${location.pathname === '/dashboard/educational-qualifications' ? 'bg-yellow-200' : ' '}  `}><Link to="/dashboard/educational-qualifications" className=" hover:underline decoration-solid decoration-2 decoration-blue-400">Educational Qualifications</Link></li>
                    <li className={`rounded-md bg-blue-50 my-4 p-3  text-xs text-black font-semibold  hover:border-2 border-blue-400 ${location.pathname === '/dashboard/guarantor-details' ? 'bg-yellow-200' : ' '}  `}><Link to="/dashboard/guarantor-details" className=" hover:underline decoration-solid decoration-2 decoration-blue-400">Guarantor Details</Link></li>
                    <li className={`rounded-md bg-blue-50 my-4 p-3  text-xs text-black font-semibold  hover:border-2 border-blue-400 ${location.pathname === '/dashboard/family-details' ? 'bg-yellow-200' : ' '}  `}><Link to="/dashboard/family-details" className=" hover:underline decoration-solid decoration-2 decoration-blue-400">Family Details</Link></li>
                    <li className={`rounded-md bg-blue-50 my-4 p-3  text-xs text-black font-semibold  hover:border-2 border-blue-400 ${location.pathname === '/dashboard/job-details' ? 'bg-yellow-200' : ' '}  `}><Link to="/dashboard/job-details" className=" hover:underline decoration-solid decoration-2 decoration-blue-400">Job Details</Link></li>
                    <li className={`rounded-md bg-blue-50 my-4 p-3  text-xs text-black font-semibold  hover:border-2 border-blue-400 ${location.pathname === '/dashboard/financial-details' ? 'bg-yellow-200' : ' '}  `}><Link to="/dashboard/financial-details" className=" hover:underline decoration-solid decoration-2 decoration-blue-400">Financial Details</Link></li>
                </ul>

            </div>
            <div className=" rounded-md w-3/5 m-6 bg-white hover:border-4 border-blue-400">
                <Outlet />
            </div>
        </div>
        </div>
    )
}
export default Dashboard;