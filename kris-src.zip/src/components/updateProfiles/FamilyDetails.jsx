function FamilyDetails () {
    return(
        <div>
            Family Details
        </div>
    )
}
export default FamilyDetails;