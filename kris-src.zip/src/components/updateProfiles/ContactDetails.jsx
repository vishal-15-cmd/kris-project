import { useForm } from 'react-hook-form';

function ContactDetails() {
    const { register, handleSubmit, formState: { errors }, watch } = useForm();
    const updateValues=(formValues)=> {
        console.log(formValues)
    }

    return (
        <div>
            <div className="mt-10 m-auto sm:mx-auto sm:w-full ">
                <form className="space-y-6 p-4 m-auto" onSubmit={handleSubmit(updateValues)} >
                    <div className="flex justify-self-start w-full text-start">
                        <div className=" m-4 w-full">
                            <label htmlFor="mobileNo1" className="block text-sm/6 font-medium text-gray-900">Mobile No1</label>
                            <div className="mt-2">
                                <input type="text" name="mobileNo1" id="mobileNo1" placeholder='Phone number1' {...register('mobileNo1', { required: { value: true, message: 'Mobileno is required' }, pattern: { value: /^[6-9]\d{9}$/, message: 'In correct mobile number' } })} className="block w-full border-0 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                <p className="text-sm text-red-400">{errors.mobileNo1?.message}</p>

                            </div>
                        </div>
                        <div className=" m-4 w-full" >
                            <label htmlFor="mobileNo2" className="block text-sm/6 font-medium text-gray-900">Mobile No2</label>
                            <div className="mt-2">
                                <input type="text" name="mobileNo2" id="mobileNo2" placeholder='Phone number2' {...register('mobileNo2', { required: { value: true, message: 'Mobileno is required' }, pattern: { value: /^[6-9]\d{9}$/, message: 'In correct mobile number' } })} className="block w-full border-0 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                <p className="text-sm text-red-400">{errors.mobileNo2?.message}</p>

                            </div>
                        </div>
                    </div>
                    <div className=" m-4 w-full ">
                        <label htmlFor="email" className="block text-sm/6 font-medium text-start text-gray-900">Email address</label>
                        <div className=" me-6">
                            <input type="text" name="email" id="email" placeholder='johndoe@gmail.com' {...register('email',{required :{value:true, message:'email is required'}, pattern :{value:/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/, message:'In correct email'}})} className="block w-full me-5 border-0 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"/>
                            <p className="text-sm text-red-400">{errors.email?.message}</p>

                        </div>
                    </div>
                    <div className="flex justify-self-start w-full text-start">
                        <div className=" m-4 w-full">
                            <label htmlFor="mobileNo1" className="block text-sm/6 font-medium text-gray-900">State of Residence</label>
                            <div className="mt-2">
                                <input type="text" name="mobileNo1" id="mobileNo1"  placeholder='Phone number1' {...register('mobileNo1', { required: { value: true, message: 'Mobileno is required' }, pattern: { value: /^[6-9]\d{9}$/, message: 'In correct mobile number' } })} className="block w-full border-0 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300  focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                <p className="text-sm text-red-400">{errors.mobileNo1?.message}</p>

                            </div>
                        </div>
                        <div className=" m-4 mt-9 w-full" >
                            <div className="mt-2">
                                <input type="text" name="mobileNo2" id="mobileNo2" placeholder='Phone number2' {...register('mobileNo2', { required: { value: true, message: 'Mobileno is required' }, pattern: { value: /^[6-9]\d{9}$/, message: 'In correct mobile number' } })} className="block w-full border-0 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                <p className="text-sm text-red-400">{errors.mobileNo2?.message}</p>

                            </div>
                        </div>
                    </div>
                    <div className=" m-4 mt-9 w-full" >
                        <label htmlFor="residentialAddress" className="block text-sm/6 text-left font-medium text-gray-900">Residential Address</label>
                        <div className="mt-2">
                        <textarea type="text" id="residentialAddress" name="residentialAddress" placeholder='18Junction site Lekki'{...register('residentialAddress')} className="block w-2/4 border-0 me-4 rounded-md bg-blue-50 px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"></textarea>
                        </div>
                    </div>


                    <div className="px-6 py-2 m-1 text-start">
                        <button type="submit" className="relative rounded-md bg-green-600 px-16 py-2 text-sm/6 font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Sign in</button>
                    </div>
                </form>
            </div>


        </div>
    )
}
export default ContactDetails;