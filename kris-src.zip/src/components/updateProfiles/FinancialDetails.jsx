function FinancialDetails () {
    return(
        <div>
            Financial Details
        </div>
    )
}
export default FinancialDetails;