
function PersonalDetails() {
    

    return (
        <div>
            
            <div className=" flex flex-wrap justify-center w-full m-auto">
                <div className="p-7  px-8 border-0 rounded-full bg-yellow-400 m-auto my-4">
                    <i className="fa-solid fa-user fa-5x">
                        <img src="" alt=""/>
                    </i>
                </div>
                <div className="m-auto mt-6 ">
                    <i className="fa-solid fa-pencil fa-2x"></i><br></br>
                    <small>Edit</small>

                </div>

            </div>
            <div className="p-4 m-1">
                <div className="p-2 m-2">
                    <h6><small><em>Employee Name</em></small></h6>
                    <h1><strong><i>Devika Medam</i></strong></h1>
                </div>
                <div className="p-2 m-2">
                    <h6><small><em>Department</em></small></h6>
                    <h1><strong><i>Design & Marketing</i></strong></h1>
                </div>
            </div>
            <div className="flex flex-wrap justify-center  p-4 m-2">
                <div className="p-2  px-4 m-auto">
                    <h6><small><em>Job Title</em></small></h6>
                    <h1><strong><i>UI / UX Designer</i></strong></h1>
                </div>
                <div className="p-2 m-auto">
                    <h6><small><em>Job category</em></small></h6>
                    <h1><strong><i>Remote</i></strong></h1>
                </div>
            </div>
        </div>
    )
}
export default PersonalDetails;