function GuarantorDetails () {
    return(
        <div>
            Guarantor Details
        </div>
    )
}
export default GuarantorDetails;