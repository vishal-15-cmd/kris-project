function JobDetails () {
    return(
        <div>
            Job Details
        </div>
    )
}
export default JobDetails;