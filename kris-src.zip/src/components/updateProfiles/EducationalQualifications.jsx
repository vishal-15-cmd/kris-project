function EducationalQualifications () {
    return(
        <div>
            Educational Qualifications
        </div>
    )
}
export default EducationalQualifications;