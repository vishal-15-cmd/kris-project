function NextOfKinDetails () {
    return(
        <div>
            Next Of Kin Details
        </div>
    )
}
export default NextOfKinDetails;